import React, { useState, useEffect } from 'react';
import io from 'socket.io-client';
import './App.css';

interface Player {
  id: string;
  username: string;
  cash: number;
  position: number;
}

interface Order {
  price: number;
  quantity: number;
  userId: string;
  timestamp: number;
  orderId: string;
}

interface GameState {
  roomCode: string;
  gameState: 'waiting' | 'active' | 'ended';
  players: Player[];
  orderBook: {
    bids: Order[];
    asks: Order[];
  };
  currentQuestion: {
    question: string;
  } | null;
  timeRemaining: number;
}

interface Trade {
  price: number;
  quantity: number;
  bidder: string;
  asker: string;
  timestamp: number;
}

const App: React.FC = () => {
  const [socket, setSocket] = useState<any>(null);
  const [gameState, setGameState] = useState<GameState | null>(null);
  const [username, setUsername] = useState('');
  const [roomCode, setRoomCode] = useState('');
  const [isHost, setIsHost] = useState(false);
  const [currentView, setCurrentView] = useState<'lobby' | 'game'>('lobby');
  const [orderForm, setOrderForm] = useState({
    type: 'bid' as 'bid' | 'ask',
    price: '',
    quantity: ''
  });
  const [recentTrades, setRecentTrades] = useState<Trade[]>([]);
  const [contractPrice, setContractPrice] = useState<number | null>(null);

  useEffect(() => {
    const socketUrl = process.env.NODE_ENV === 'production' 
      ? window.location.origin 
      : 'http://localhost:5000';
    const newSocket = io(socketUrl);
    setSocket(newSocket);

    newSocket.on('roomCreated', (data: { roomCode: string }) => {
      setRoomCode(data.roomCode);
      setIsHost(true);
      setCurrentView('game');
    });

    newSocket.on('roomJoined', (data: { roomCode: string }) => {
      setRoomCode(data.roomCode);
      setIsHost(false);
      setCurrentView('game');
    });

    newSocket.on('gameState', (state: GameState) => {
      setGameState(state);
    });

    newSocket.on('gameStarted', (data: { question: string; timeRemaining: number }) => {
      setCurrentView('game');
    });

    newSocket.on('orderBookUpdate', (data: { bids: Order[]; asks: Order[] }) => {
      setGameState(prev => prev ? { ...prev, orderBook: data } : null);
    });

    newSocket.on('tradeExecuted', (trade: Trade) => {
      setRecentTrades(prev => [trade, ...prev.slice(0, 9)]); // Keep last 10 trades
    });

    newSocket.on('gameEnded', (data: { contractPrice: number; explanation: string; finalBalances: any[] }) => {
      setContractPrice(data.contractPrice);
      setCurrentView('lobby');
    });

    newSocket.on('error', (data: { message: string }) => {
      alert(data.message);
    });

    return () => {
      newSocket.close();
    };
  }, []);

  const createRoom = () => {
    if (!username.trim()) {
      alert('Please enter a username');
      return;
    }
    socket?.emit('createRoom', { username: username.trim() });
  };

  const joinRoom = () => {
    if (!username.trim() || !roomCode.trim()) {
      alert('Please enter both username and room code');
      return;
    }
    socket?.emit('joinRoom', { 
      username: username.trim(), 
      roomCode: roomCode.trim().toUpperCase() 
    });
  };

  const startGame = () => {
    socket?.emit('startGame');
  };

  const placeOrder = () => {
    const price = parseFloat(orderForm.price);
    const quantity = parseInt(orderForm.quantity);

    if (isNaN(price) || isNaN(quantity) || price < 1 || quantity < 20) {
      alert('Price must be at least $1 and quantity at least 20');
      return;
    }

    socket?.emit('placeOrder', {
      type: orderForm.type,
      price,
      quantity
    });

    setOrderForm({ type: 'bid', price: '', quantity: '' });
  };

  const cancelOrder = (type: 'bid' | 'ask') => {
    socket?.emit('cancelOrder', { type });
  };

  const formatTime = (ms: number) => {
    const minutes = Math.floor(ms / 60000);
    const seconds = Math.floor((ms % 60000) / 1000);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const getCurrentPlayer = () => {
    return gameState?.players.find(p => p.id === socket?.id);
  };

  if (currentView === 'lobby') {
    return (
      <div className="app">
        <div className="lobby">
          <h1>Fermi Market Game</h1>
          <div className="lobby-form">
            <input
              type="text"
              placeholder="Enter your username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              maxLength={20}
            />
            <div className="lobby-actions">
              <button onClick={createRoom} className="create-room-btn">
                Create Room
              </button>
              <div className="join-section">
                <input
                  type="text"
                  placeholder="Room Code"
                  value={roomCode}
                  onChange={(e) => setRoomCode(e.target.value.toUpperCase())}
                  maxLength={6}
                />
                <button onClick={joinRoom} className="join-room-btn">
                  Join Room
                </button>
              </div>
            </div>
          </div>
          {contractPrice && (
            <div className="game-result">
              <h2>Game Ended!</h2>
              <p>Contract Price: ${contractPrice.toLocaleString()}</p>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="app">
      <div className="game-container">
        <div className="game-header">
          <h1>Room: {roomCode}</h1>
          {isHost && gameState?.gameState === 'waiting' && (
            <button onClick={startGame} className="start-game-btn">
              Start Game
            </button>
          )}
          {gameState?.gameState === 'active' && (
            <div className="timer">
              Time Remaining: {formatTime(gameState.timeRemaining)}
            </div>
          )}
        </div>

        <div className="game-content">
          <div className="left-panel">
            <div className="question-panel">
              <h2>Fermi Question</h2>
              {gameState?.currentQuestion ? (
                <p>{gameState.currentQuestion.question}</p>
              ) : (
                <p>Waiting for game to start...</p>
              )}
            </div>

            <div className="player-info">
              <h3>Your Account</h3>
              {getCurrentPlayer() && (
                <div className="account-details">
                  <p>Cash: ${getCurrentPlayer()!.cash.toLocaleString()}</p>
                  <p>Position: {getCurrentPlayer()!.position} shares</p>
                  <p>Net Worth: ${(getCurrentPlayer()!.cash + (getCurrentPlayer()!.position * (contractPrice || 0))).toLocaleString()}</p>
                </div>
              )}
            </div>

            <div className="order-form">
              <h3>Place Order</h3>
              <div className="order-type">
                <button
                  className={orderForm.type === 'bid' ? 'active' : ''}
                  onClick={() => setOrderForm({ ...orderForm, type: 'bid' })}
                >
                  Buy (Bid)
                </button>
                <button
                  className={orderForm.type === 'ask' ? 'active' : ''}
                  onClick={() => setOrderForm({ ...orderForm, type: 'ask' })}
                >
                  Sell (Ask)
                </button>
              </div>
              <input
                type="number"
                placeholder="Price ($)"
                value={orderForm.price}
                onChange={(e) => setOrderForm({ ...orderForm, price: e.target.value })}
                min="1"
                step="1"
              />
              <input
                type="number"
                placeholder="Quantity (min 20)"
                value={orderForm.quantity}
                onChange={(e) => setOrderForm({ ...orderForm, quantity: e.target.value })}
                min="20"
                step="20"
              />
              <button onClick={placeOrder} className="place-order-btn">
                Place {orderForm.type === 'bid' ? 'Bid' : 'Ask'}
              </button>
              <div className="cancel-orders">
                <button onClick={() => cancelOrder('bid')} className="cancel-btn">
                  Cancel Bid
                </button>
                <button onClick={() => cancelOrder('ask')} className="cancel-btn">
                  Cancel Ask
                </button>
              </div>
            </div>
          </div>

          <div className="right-panel">
            <div className="order-book">
              <h3>Order Book</h3>
              <div className="order-book-content">
                <div className="asks">
                  <h4>Sells (Asks)</h4>
                  <div className="order-list">
                    {gameState?.orderBook.asks.slice(0, 10).map((ask, index) => (
                      <div key={ask.orderId} className="order-row ask-row">
                        <span className="price">${ask.price}</span>
                        <span className="quantity">{ask.quantity}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="bids">
                  <h4>Buys (Bids)</h4>
                  <div className="order-list">
                    {gameState?.orderBook.bids.slice(0, 10).map((bid, index) => (
                      <div key={bid.orderId} className="order-row bid-row">
                        <span className="price">${bid.price}</span>
                        <span className="quantity">{bid.quantity}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="recent-trades">
              <h3>Recent Trades</h3>
              <div className="trades-list">
                {recentTrades.map((trade, index) => (
                  <div key={index} className="trade-row">
                    <span className="trade-price">${trade.price}</span>
                    <span className="trade-quantity">{trade.quantity}</span>
                    <span className="trade-participants">
                      {trade.bidder} ↔ {trade.asker}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <div className="leaderboard">
              <h3>Leaderboard</h3>
              <div className="players-list">
                {gameState?.players
                  .sort((a, b) => (b.cash + (b.position * (contractPrice || 0))) - (a.cash + (a.position * (contractPrice || 0))))
                  .map((player, index) => (
                    <div key={player.id} className="player-row">
                      <span className="rank">#{index + 1}</span>
                      <span className="username">{player.username}</span>
                      <span className="cash">${player.cash.toLocaleString()}</span>
                      <span className="position">{player.position} shares</span>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;